function LSFLA
 
 
num=1;
M=30;

MAX_FES=M*1e4;%0.3-1.9

 
  for   problemIndex=1
 
  
   %容呪議歌方譜�?

 onebest=zeros(1,num);%耽�?痕方25倖恷單盾
 allbest=zeros(num,MAX_FES);%耽�?痕娩25肝塰佩議侭嗤單盾
 
  le=9;
  m=4;
   n=5;
  q=m*n;
  
   beta=0.6;
   
  
    %容呪議歌方譜�?
   for tdy=1:num
      rand('seed', sum(100*clock));
     
     FES=0;%癖哘業峙方朕兜兵�?
 
            
           
         switch problemIndex

        case 1
            % 1.This is sphere function
                       Dmin= -100;
                       Dmax =100;
                        func_num=1;%得浩痕方
                       bestvalue=0;
                          success_threshold=1e-5; 
                          
        case 2
                     %Schwefel¨s Problem 2.22 [-10,10],0
                      Dmin= -10;
                       Dmax =10;
                        func_num=7;%得浩痕方
                       bestvalue=0;
                          success_threshold=1e-5; 
                         
      case 3
                     %Schwefel¨s Problem 1.2 ,[100,100],[0]
                      Dmin= -100;
                      Dmax =100;
                      func_num=11;%得浩痕方
                     bestvalue=0;
                      success_threshold=1e-5; 
                      
     case 4
                     %Quartic function  [-1.28,1.28],[0]
                      Dmin= -1.28;
                      Dmax =1.28;
                      func_num=14;%得浩痕方
                     bestvalue=0;
                      success_threshold=1e-5; 
                       
        case 5
            % 2.This Rastrigrin Function
                      Dmin= -5.12;
                      Dmax =5.12;
                      func_num=2;%得浩痕方 = []; alpha = []; b = [];
                      bestvalue=0;
                      success_threshold=1e-1; 
                    
        case 6 
            % This is Ackley Function
                % x is a vector[-32,32],opt=0
                   Dmin= -32;
                   Dmax =32;
                  func_num=3;%得浩痕方
                   bestvalue=0;
                      success_threshold=1e-5; 
                    
         end
             
 
frog=struct('fitness',{},'center',{});
   frogA=zeros(q,M);
 
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
for i=1:q 
          data=Dmin+(Dmax-Dmin)*rand(1,M); 
          
            fitness=benchmark_func(data,func_num)
            
           frog(i).fitness=fitness;
           frog(i).center=data;
           
           FES=FES+1;
           
           if i==1
               tempFrog=frog(1);
               
           end
           
           if frog(i).fitness< tempFrog.fitness
               tempFrog=frog(i);
             
           end
              allbest(tdy,FES)= tempFrog.fitness;
               
              fprintf('fitFrog(%d) =%g\n',FES,allbest(tdy,FES));
end
 

  
%%%%%%%%%%%%%%%%%
 
 v=0;
while FES<=MAX_FES%詞栽電會
        if  FES>MAX_FES
                break;
       end
    
           v=v+1;
   
         for I=1:q-1
             for J=1:q-I
                if frog(J).fitness < frog(J+1).fitness
                     temp=frog(J+1).fitness;
                     temp2=frog(J+1).center;
            
                      frog(J+1).fitness=frog(J).fitness;
                      frog(J+1).center=frog(J).center;
             
                      frog(J).center=temp2;
                      frog(J).fitness=temp;
                end 
             end
         end
                   Xg=frog(q);
              
       for k=1:le%蕉何亨旗
                   if  FES>MAX_FES
                                break;
                   end
                 
            for i=1:m
                      
                    Xw= frog(i);
                    w=i;
                     Xb= frog(i);
                     b=i;
           
                    for tt=2:n
                         if  frog(i+m*(tt-1)).fitness<Xb.fitness
                             Xb=frog(i+m*(tt-1));
                             b=i+m*(tt-1);
                         end
                         if  frog(i+m*(tt-1)).fitness>Xw.fitness
                            Xw=frog(i+m*(tt-1));
                            w=i+m*(tt-1);%潤更悶方怏議沫哈�?
                         end

                    end
                   
                         Xnew=Xw;
                            
                  sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
                      u=randn(size(frog(1).center))*sigma;
                   vw=randn(size(frog(1).center));
                  step=u./abs(vw).^(1/beta)   ;
                  
                 stepsize=  randn.*(randn) .*step;%levy 敬佩化海
%                  stepsize=  rand.*(randn) .*step;
                 
                      Xnew.center =Xw.center + rand.* (stepsize.*Xb.center-Xw.center);   
%                            
                              data=Xnew.center;
                             data(data>Dmax)=Dmax;
                             data(data<Dmin)=Dmin;
                               
                          Xnew.center =data;
                  
                         Xnew.fitness=benchmark_func(data,func_num);
                            
                         FES= FES+1;
                          if Xnew.fitness<Xw.fitness
                           Xw=Xnew;
                           
                          end
                           frog(w)=Xw;
                            
                           if   Xnew.fitness< tempFrog.fitness    
                                   tempFrog=Xnew;
                                 
                           end
                           
                             if  FES>MAX_FES
                                break;
                             end
                                allbest(tdy,FES)= tempFrog.fitness;
                                
                             if mod(FES,2113)==0
                               fprintf('fitFrog(%d) =%g\n',FES,allbest(tdy,FES));
                             end
                             
                             % 
                            
           end%m 
      end%le 
      %global search 
      
        for iii=1:q         
          frogA(iii,:)=frog(iii).center;    
        end
        K=rand(size(frogA))>0   ;
        stepsize=rand*(frogA(randperm(q),:)-frogA(randperm(q),:)) ;
      new_frogA=frogA+stepsize.* K; 
  
      for jjj=1:q
           data=new_frogA(jjj,:);
           data(data>Dmax)=Dmax;
           data(data<Dmin)=Dmin;
           fitness=benchmark_func(data,func_num);
            
           if fitness<frog(jjj).fitness
               frog(jjj).center=data;
               frog(jjj).fitness=fitness;   
           end  
             FES= FES+1;
             % 
                           
          if  fitness< tempFrog.fitness    
                  tempFrog.center=data;
                 tempFrog.fitness=fitness;
          end
                           
           if  FES>MAX_FES
                            break;
              end
              allbest(tdy,FES)= tempFrog.fitness;
                              
                if mod(FES,2113)==0
                               fprintf('fitFrog(%d) =%g\n',FES,allbest(tdy,FES));
               end
                             
                 % 
            
      end
         
       %畠蕉朴沫
       
      end%while FES<=MAX_FES%
         tempFrog.center
        onebest(tdy)=allbest (tdy,MAX_FES)
        size(allbest,2)
%           c01='D:\matlabCode\LSFLA\data\LSFLA\SIM\onebest';
%          d01=[c01  num2str(problemIndex)];
%          d01=[d01  num2str(cansu1)];
%         save(d01, 'onebest');
%          
%         c02='D:\matlabCode\LSFLA\data\LSFLA\SIM\allbest';
%         d02=[c02  num2str(problemIndex)];
%         d02=[d02  num2str(cansu1)];
%          save( d02, 'allbest');
    end% tdy
       
 
  end%25倖痕�?
       
function f=benchmark_func(data,func_num)

switch func_num

        case 1
             
            f=f1(data);
            
        case 2

           f=f2(data);
           
        case 3
            
            f=f3(data);
            
        case 4
            
            f=f4(data);
            
        case 5
            
            f=f5(data);
            
        case 6
            
               f=f6(data);
          
end
 

   function y=f1(x)
% This is sphere function
% x is a vector[-100,100],opt=0
d=length(x);
y=0;
for k=1:d
    y=y+x(k)^2;
end

function y=f2(x)
% This Rastrigrin Function
% x is a vector[-5.12,5.12],opt=0
d=length(x);
y=0;
for k=1:d
    y=y+(x(k)^2-10*cos(2*pi*x(k))+10);
end

function result=f3(x)
% This is Ackley Function
% x is a vector[-32,32],opt=0
%Ackley ����  
%����x,������Ӧ��yֵ,��x=(0,0,��,0) ����ȫ�ּ�С��0,Ϊ�õ����ֵ������ֵȡ�෴��  
%�����ˣ�  
%�������ڣ�  
[row,col]=size(x);  
if row>1  
    error('����Ĳ�������');  
end  
result=-20*exp(-0.2*sqrt((1/col)*(sum(x.^2))))-exp((1/col)*sum(cos(2*pi.*x)))+exp(1)+20;  
   
% d=length(x);
% y1=20*exp((-0.2)*sqrt(sum(x.^2)/d));
% y2=exp(sum(cos(2*pi*x))/d);
% y=20+exp(1)-y1-y2;
        
function y=f4(x)
% This is Griewank Function
% x is a vector[-600,600],opt=0
d=length(x);
y1=0;
y2=1.0;
for k=1:d
    %y1=y1+(x(k)-100)^2;
      y1=y1+(x(k))^2;
    % y2=y2*cos((x(k)-100)/sqrt(k));
    y2=y2*cos((x(k))/sqrt(k));
end
y=y1/4000-y2+1;

function y=f5(data)
  %Shaffer  function
    f1=0;
    f1=0.5+(  sin(  sqrt( data(1)^2+data(2)^2 ) ).^2-0.5    )/(  1+0.001*(  data(1)^2+data(2)^2 )  ).^2  ; 
    y=f1;
    
      function y=f6(x)
% f1 is Rosenbrock function
% The variabe x is a vector
%
d=length(x);
z=0;
for k=1:d-1
  z=z+(100*(x(k+1)-x(k)^2)^2+(x(k)-1)^2);
end
y=z;
 
            
            
     
            
 